<?php

echo "<h2>Simple File Viewer</h2>";
echo "<p>Try to read files on the server.</p>";

$file = $_GET['file'] ?? 'index.php';

// ❌ Vulnerable: no sanitization
$content = @file_get_contents($file);

if ($content === false) {
    echo "Could not read file.";
} else {
    echo "<pre>" . htmlspecialchars($content) . "</pre>";
}

?>
